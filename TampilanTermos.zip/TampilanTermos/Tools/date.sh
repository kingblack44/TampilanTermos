#-----SUBSCRIBE MY YOUTUBE Din-zUgex95-----#


date=`date "+%d"`
month=`date "+%m"`
years=`date "+%y"`

day=`date "+%A"`


echo "  \033[95m╼\033[94m☾ \033[93mDATE \033[95m: \033[92m$date\033[95m/\033[92m$month\033[95m/\033[92m$years \033[94m☽\033[95m╾╼\033[94m☾ \033[93mDAY \033[95m: \033[92m$day \033[94m☽\033[95m╾"
echo
echo
